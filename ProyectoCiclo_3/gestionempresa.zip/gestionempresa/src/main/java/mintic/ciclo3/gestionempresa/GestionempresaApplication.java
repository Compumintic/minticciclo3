package mintic.ciclo3.gestionempresa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionempresaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionempresaApplication.class, args);
	}

}
