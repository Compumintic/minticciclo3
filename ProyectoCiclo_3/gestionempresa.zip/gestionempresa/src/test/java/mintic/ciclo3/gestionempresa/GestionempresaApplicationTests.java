package mintic.ciclo3.gestionempresa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionempresaApplicationTests {

	@Test
	void contextLoads() {
	}

}
